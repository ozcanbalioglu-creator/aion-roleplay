# Design System Specification: High-End Editorial

## 1. Overview & Creative North Star
**Creative North Star: The Intellectual Mirror**
This design system is built on the philosophy of "The Intellectual Mirror"—an interface that reflects professional excellence, clarity, and deep introspection. We move away from the "software-as-a-tool" aesthetic toward a "software-as-a-sanctum" experience. 

By leveraging a high-contrast split-screen layout—where the deep `on_background` (#1A1A2E) anchors the narrative and the luminous `surface` (#FCF8FF) facilitates action—we create a psychological transition between reflection and execution. The design breaks traditional grids through intentional asymmetry, using "Newsreader" italics to highlight emotional resonance and "Manrope" for clinical precision.

---

## 2. Colors: Tonal Depth & Atmospheric UI
Our palette is rooted in a deep midnight foundation, accented by luminous lavender highlights that feel like light breaking through a prism.

### The "No-Line" Rule
**Explicit Instruction:** 1px solid borders are strictly prohibited for sectioning. We define space through background shifts, not outlines. 
- A section within a `surface` area should use `surface_container_low` to define its boundary.
- For high-contrast dark sections, use `primary_container` (#2A0056) to house inner modules against the `on_background`.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper and frosted glass. 
- **Base Layer:** `surface` (#FCF8FF)
- **Secondary Tier:** `surface_container_low` (#F5F2FF) for subtle grouping.
- **Elevation Tier:** `surface_container_highest` (#E2E0FC) for interactive cards.

### Signature Textures & Glassmorphism
To achieve a bespoke, premium feel, use "Glassmorphism" for floating navigation or overlay panels. 
- **Glass Formula:** Apply `surface_container_lowest` (#FFFFFF) at 70% opacity with a `24px` backdrop blur.
- **The Glow:** Utilize subtle radial gradients transitioning from `primary` (#020007) to `primary_container` (#2A0056) in dark regions to create atmospheric depth rather than flat, dead space.

---

## 3. Typography: The Editorial Voice
Typography is the primary vehicle for the brand’s "Trustworthy" and "Sophisticated" personality.

- **Display & Headlines (Newsreader):** Use large-scale serif for impact. **The Signature Move:** Always use the italic variant for key emotional words within a sentence (e.g., "See *yourself* clearly"). This creates a rhythmic, editorial flow.
- **Body & Labels (Manrope):** A clean, geometric sans-serif that ensures absolute readability.
- **Hierarchy as Identity:** 
    - `display-lg` (3.5rem) is reserved for high-level philosophical statements.
    - `label-md` (0.75rem) in all-caps with `0.1em` letter-spacing should be used for category headers to create a sense of professional curation.

---

## 4. Elevation & Depth: Tonal Layering
We eschew traditional "Drop Shadows" for a more natural, ambient lighting model.

- **The Layering Principle:** Place a `surface_container_lowest` card on top of a `surface_container_low` background. The slight shift in hex value provides a sophisticated, "borderless" lift.
- **Ambient Shadows:** When a shadow is necessary (e.g., for a floating CTA or modal), use:
    - `Y: 12px, Blur: 32px, Color: #1A1A2E (6% opacity)`. This mimics the way heavy paper casts a soft shadow on a desk.
- **The "Ghost Border" Fallback:** If accessibility requires a stroke, use `outline_variant` (#C8C5CD) at **15% opacity**. It must be felt, not seen.
- **Glass Layering:** Overlapping elements should utilize the split-screen seam. A dark card can "bleed" into the light side of the layout to create an asymmetrical, modern interlocking effect.

---

## 5. Components: Bespoke Primitives

### Buttons
- **Primary:** `on_background` (#1A1A2E) fill with `surface` text. Shape: `full` (pill). No border.
- **Secondary:** `surface_container_highest` fill with `on_primary_container` (#9D6BDF) text.
- **Tertiary:** Text-only with a `Newsreader` italic accent. On hover, a 1px underline using `surface_tint`.

### Input Fields
- **Styling:** Use `surface_container_lowest` backgrounds. 
- **Borders:** Forbid standard gray borders. Use a `1px` stroke of `outline_variant` at 20% opacity. On focus, the stroke should transition to `on_primary_container` (#9D6BDF).
- **Labels:** Always use `label-md` Manrope, all-caps, with subtle tracking.

### Cards & Lists
- **The Divider Rule:** Strictly no horizontal lines. Use `16px` to `24px` of vertical whitespace to separate list items. 
- **Cards:** Use `md` (0.75rem) roundedness. Cards should not have shadows unless they are "Actionable Hover" states.

### Coaching Specific Components
- **The Mirror Metric:** A progress visualization using a dual-tone gradient from `primary_container` to `on_primary_container`.
- **Session Chips:** Use `secondary_container` (#E2E0FC) with `on_secondary_container` text for a soft, low-cognitive-load metadata display.

---

## 6. Do’s and Don’ts

### Do:
- **Do** embrace the split-screen. Use the dark side for "Discovery/Context" and the light side for "Action/Inputs."
- **Do** use large amounts of "Negative Space." If a section feels crowded, double the padding.
- **Do** use `Newsreader` italics for emphasis to create a "Human" touch in a professional environment.

### Don't:
- **Don't** use pure black (#000000). Use our `primary` or `on_background` for a softer, more expensive look.
- **Don't** use standard 1px borders to separate content. Use background tonal shifts.
- **Don't** use "Default" blue for links. Use the sophisticated `on_primary_container` (#9D6BDF).
- **Don't** use sharp corners. Use the `DEFAULT` (0.5rem) or `md` (0.75rem) scale to maintain a "Professional yet Approachable" tone.